

import React from "react";
import Slide from "../Components/Slide";

const Home = () => {
  return (
    <div>
      <Slide />
      
    </div>
  );
};

export default Home;
